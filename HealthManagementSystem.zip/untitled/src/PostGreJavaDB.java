
import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class PostGreJavaDB {
    public static void main(String[] args) {
        String url = "jdbc:postgresql://localhost:5432/HealthClub";
        String user = "postgres";
        String password = "Idcbruh1";
        try  {
            Connection conn = DriverManager.getConnection(url, user, password);
            System.out.println("Connected to PostgreSQL successfully!");


            Scanner scanner = new Scanner(System.in);
            System.out.println("Welcome to the Fitness Club System");
            while (true) {
                System.out.println("Please choose an option:");
                System.out.println("1. Register as a new member");
                System.out.println("2. Update profile");
                System.out.println("3. Member Schedule");
                System.out.println("4. Trainer Schedule");
                System.out.println("5. Member Search");
                System.out.println("6. Manage a session(Staff)");
                System.out.println("7. Pay outstanding bills");
                System.out.println("8. Maintain Equipment(Staff)");
                System.out.println("0. Exit");

                String choice = scanner.nextLine();
                switch (choice) {
                    case "1":
                        registerMember(scanner, conn);
                        break;
                    case "2":
                        updateProfile(scanner, conn);
                        break;
                    case "3":
                        memberScheduling(scanner, conn);
                        break;
                    case "4":
                        trainerManageSchedule(scanner, conn);
                        break;
                    case "5":
                        searchMembers(scanner, conn);
                        break;
                    case "6":
                        scheduleSessionWithTrainer(scanner, conn);
                        break;
                    case "7":
                        payBills(scanner, conn);
                        break;
                    case "8":
                        checkAndMaintainEquipment(scanner, conn);
                        break;
                    case "0":
                        System.out.println("Exiting...");
                        return;
                }
            }
        } catch (SQLException e) {
            System.out.println("Failed to establish connection.");
            e.printStackTrace();
        }
    }
    private static void payBills(Scanner scanner, Connection conn) {
        try {
            System.out.println("Enter the Member ID to pay bills:");
            int memberId = Integer.parseInt(scanner.nextLine());

            // Display all unpaid bills for the member
            String querySQL = "SELECT BillID, Amount, DueDate FROM Bills WHERE MemberID = ? AND Status = 'Due'";
            try (PreparedStatement pstmt = conn.prepareStatement(querySQL)) {
                pstmt.setInt(1, memberId);
                ResultSet rs = pstmt.executeQuery();
                System.out.println("Unpaid Bills:");
                while (rs.next()) {
                    System.out.println("Bill ID: " + rs.getInt("BillID") +
                            ", Amount: " + rs.getBigDecimal("Amount") +
                            ", Due Date: " + rs.getDate("DueDate"));
                }
            }

            System.out.println("Enter the Bill ID to pay:");
            int billId = Integer.parseInt(scanner.nextLine());

            // Update the bill status to "Paid"
            String updateSQL = "UPDATE Bills SET Status = 'Paid' WHERE BillID = ? AND MemberID = ?";
            try (PreparedStatement pstmtUpdate = conn.prepareStatement(updateSQL)) {
                pstmtUpdate.setInt(1, billId);
                pstmtUpdate.setInt(2, memberId);
                int affectedRows = pstmtUpdate.executeUpdate();

                if (affectedRows == 0) {
                    System.out.println("No bill was updated, please check the Bill ID and Member ID.");
                } else {
                    System.out.println("Bill paid successfully.");
                }
            }

        }  catch (Exception e) {
            System.err.println("An error occurred.");
            e.printStackTrace();
        }
    }
    private static void checkAndMaintainEquipment(Scanner scanner, Connection conn) {
        try {
            conn.setAutoCommit(false); // Start transaction control

            // List equipment that needs maintenance
            System.out.println("Equipment needing maintenance:");
            String equipmentSQL = "SELECT EquipmentID, Type, LastMaintenanceDate FROM Equipment WHERE NeedingMaintenance = TRUE";
            try (PreparedStatement pstmtEquipment = conn.prepareStatement(equipmentSQL)) {
                ResultSet rsEquipment = pstmtEquipment.executeQuery();
                boolean hasEquipmentNeedingMaintenance = false;
                while (rsEquipment.next()) {
                    System.out.println("Equipment ID: " + rsEquipment.getInt("EquipmentID") +
                            ", Type: " + rsEquipment.getString("Type") +
                            ", Last Maintenance Date: " + rsEquipment.getDate("LastMaintenanceDate"));
                    hasEquipmentNeedingMaintenance = true;
                }
                if (!hasEquipmentNeedingMaintenance) {
                    System.out.println("No equipment currently needs maintenance.");
                    return;
                }
            }

            System.out.println("Enter the Equipment ID to maintain:");
            int equipmentId = Integer.parseInt(scanner.nextLine());

            System.out.println("Enter your Staff ID:");
            int staffId = Integer.parseInt(scanner.nextLine());

            // Update equipment maintenance status and record the maintenance
            String updateEquipmentSQL = "UPDATE Equipment SET NeedingMaintenance = FALSE, LastMaintenanceDate = CURRENT_DATE WHERE EquipmentID = ?";
            try (PreparedStatement pstmtUpdateEquipment = conn.prepareStatement(updateEquipmentSQL)) {
                pstmtUpdateEquipment.setInt(1, equipmentId);
                int affectedRows = pstmtUpdateEquipment.executeUpdate();
                if (affectedRows == 0) {
                    System.out.println("No equipment was updated, please check the Equipment ID.");
                } else {
                    System.out.println("Equipment maintenance updated successfully.");

                    // Log the maintenance activity
                    String insertMaintenanceSQL = "INSERT INTO Equipment_Maintenance (EquipmentID, StaffID, Date) VALUES (?, ?, CURRENT_DATE)";
                    try (PreparedStatement pstmtInsertMaintenance = conn.prepareStatement(insertMaintenanceSQL)) {
                        pstmtInsertMaintenance.setInt(1, equipmentId);
                        pstmtInsertMaintenance.setInt(2, staffId);
                        pstmtInsertMaintenance.executeUpdate();
                        System.out.println("Maintenance activity logged successfully.");
                    }
                }
            }

            conn.commit(); // Commit the transaction

        }  catch (Exception e) {
            System.err.println("An error occurred.");
            e.printStackTrace();
        }
    }
    private static void scheduleSessionWithTrainer(Scanner scanner, Connection conn) {
        try {
            conn.setAutoCommit(false); // Start transaction control

            // List available trainers
            System.out.println("Available Trainers:");
            String trainerSQL = "SELECT TrainerID, Name, Specialization FROM Trainer";
            try (PreparedStatement pstmtTrainer = conn.prepareStatement(trainerSQL)) {
                ResultSet rsTrainers = pstmtTrainer.executeQuery();
                while (rsTrainers.next()) {
                    System.out.println("Trainer ID: " + rsTrainers.getInt("TrainerID") +
                            ", Name: " + rsTrainers.getString("Name") +
                            ", Specialization: " + rsTrainers.getString("Specialization"));
                }
            }

            System.out.println("Select a Trainer ID:");
            int trainerId = Integer.parseInt(scanner.nextLine());

            // List available rooms
            System.out.println("Available Rooms:");
            String roomSQL = "SELECT RoomID, RoomType, Capacity FROM Room";
            try (PreparedStatement pstmtRoom = conn.prepareStatement(roomSQL)) {
                ResultSet rsRooms = pstmtRoom.executeQuery();
                while (rsRooms.next()) {
                    System.out.println("Room ID: " + rsRooms.getInt("RoomID") +
                            ", Type: " + rsRooms.getString("RoomType") +
                            ", Capacity: " + rsRooms.getInt("Capacity"));
                }
            }

            System.out.println("Select a Room ID:");
            int roomId = Integer.parseInt(scanner.nextLine());

            // Collect session details
            System.out.println("Enter the date for the session (YYYY-MM-DD):");
            String dateInput = scanner.nextLine();
            java.sql.Date date = java.sql.Date.valueOf(dateInput);

            System.out.println("Enter the time for the session (HH:MM):");
            String timeInput = scanner.nextLine();
            java.sql.Time time = java.sql.Time.valueOf(timeInput + ":00");

            System.out.println("Enter the type of session (e.g., Yoga, Personal Training, Cardio):");
            String sessionType = scanner.nextLine();

            System.out.println("Enter the duration of the session in minutes:");
            int durationMinutes = Integer.parseInt(scanner.nextLine());
            String duration = "PT" + durationMinutes + "M"; // ISO-8601 duration format for PostgreSQL interval type

            // Insert the new session
            String insertSQL = "INSERT INTO Sessions (TrainerID, RoomID, Date, Time, SessionType, Duration) VALUES (?, ?, ?, ?, ?, CAST(? AS INTERVAL))";
            try (PreparedStatement pstmtInsert = conn.prepareStatement(insertSQL)) {
                pstmtInsert.setInt(1, trainerId);
                pstmtInsert.setInt(2, roomId);
                pstmtInsert.setDate(3, date);
                pstmtInsert.setTime(4, time);
                pstmtInsert.setString(5, sessionType);
                pstmtInsert.setString(6, duration); // Passing the ISO-8601 formatted string for interval

                int affectedRows = pstmtInsert.executeUpdate();
                if (affectedRows == 0) {
                    throw new SQLException("Creating session failed, no rows affected.");
                }

                conn.commit(); // Commit the transaction
                System.out.println("Session scheduled successfully for trainer ID " + trainerId + " in room ID " + roomId + " on " + date + " at " + time + " for duration " + durationMinutes + " minutes.");
            }
        } catch (Exception e) {
            System.err.println("An error occurred.");
            e.printStackTrace();
        }
    }
    private static void searchMembers(Scanner scanner, Connection conn) {
        try {
            System.out.println("Enter the member name or part of the name to search:");
            String memberName = scanner.nextLine();

            // Prepare the SQL query to fetch members matching the name
            String querySQL = "SELECT MemberID, Name, Email, Phone FROM Member WHERE Name ILIKE ?";
            try (PreparedStatement pstmt = conn.prepareStatement(querySQL)) {
                pstmt.setString(1, "%" + memberName + "%"); // Use ILIKE for case-insensitive search

                ResultSet rs = pstmt.executeQuery();
                boolean found = false;

                System.out.println("Search Results:");
                while (rs.next()) {
                    // Print each member found
                    System.out.println("Member ID: " + rs.getInt("MemberID") + ", Name: " + rs.getString("Name") + ", Email: " + rs.getString("Email") + ", Phone: " + rs.getString("Phone"));
                    found = true;
                }

                if (!found) {
                    System.out.println("No members found with the name '" + memberName + "'");
                }
            }
        }catch (Exception e) {
            System.err.println("An error occurred.");
            e.printStackTrace();
        }
    }
    private static void registerMember(Scanner scanner, Connection conn) {
        try {
            conn.setAutoCommit(false);

            // Collect user information
            System.out.println("Enter your full name:");
            String name = scanner.nextLine();

            System.out.println("Enter your email address:");
            String email = scanner.nextLine();

            System.out.println("Enter your address:");
            String address = scanner.nextLine();

            System.out.println("Enter your phone number:");
            String phone = scanner.nextLine();

            System.out.println("Enter your gender:");
            String gender = scanner.nextLine();

            System.out.println("Enter your height (in centimeters):");
            double height = Double.parseDouble(scanner.nextLine());

            System.out.println("Enter your weight (in kilograms):");
            double weight = Double.parseDouble(scanner.nextLine());

            System.out.println("Enter your body fat percentage:");
            double bodyFat = Double.parseDouble(scanner.nextLine());

            System.out.println("Enter your weight goal (in kilograms):");
            double weightGoal = Double.parseDouble(scanner.nextLine());

            System.out.println("Enter your body fat goal percentage:");
            double bodyFatGoal = Double.parseDouble(scanner.nextLine());


            System.out.println("Select a membership (enter the MembershipID):\n (1) 12 months: 99.99, (2) 6 months: 59.99, (3) 3 months: 34.99");
            int membershipId = Integer.parseInt(scanner.nextLine());

            String memberSQL = "INSERT INTO Member (Name, Email, Address, Phone, Gender, Height, Weight, BodyFat, WeightGoal, WeightGoalStatus, BodyFatGoal, BodyFatGoalStatus, MembershipID) "
                    + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'Pending', ?, 'Pending', ?) RETURNING MemberID";
            try (PreparedStatement pstmtMember = conn.prepareStatement(memberSQL)) {
                pstmtMember.setString(1, name);
                pstmtMember.setString(2, email);
                pstmtMember.setString(3, address);
                pstmtMember.setString(4, phone);
                pstmtMember.setString(5, gender);
                pstmtMember.setDouble(6, height);
                pstmtMember.setDouble(7, weight);
                pstmtMember.setDouble(8, bodyFat);
                pstmtMember.setDouble(9, weightGoal);
                pstmtMember.setDouble(10, bodyFatGoal);
                pstmtMember.setInt(11, membershipId);

                ResultSet rsMember = pstmtMember.executeQuery();

                if (!rsMember.next()) {
                    throw new SQLException("Failed to insert new member.");
                }
                int newMemberId = rsMember.getInt(1);

                String membershipPriceSQL = "SELECT Price FROM Memberships WHERE MembershipID = ?";
                Double membershipPrice;
                try (PreparedStatement pstmtPrice = conn.prepareStatement(membershipPriceSQL)) {
                    pstmtPrice.setInt(1, membershipId);
                    ResultSet rsPrice = pstmtPrice.executeQuery();
                    if (!rsPrice.next()) {
                        throw new SQLException("Membership ID not found.");
                    }
                    membershipPrice = rsPrice.getDouble("Price");
                }
                System.out.println("The membership fee is " + membershipPrice + ". How would you like to pay?\n(1) Cash or (2) Credit");
                String paymentChoice = scanner.nextLine();
                String paymentType;
                switch (paymentChoice) {
                    case "1":
                        paymentType = "Cash";
                        break;
                    case "2":
                        paymentType = "Credit";
                        break;
                    default:
                        System.out.println("Invalid payment method. Registration cancelled.");
                        return;
                }

                String billsSQL = "INSERT INTO Bills (Amount, DueDate, PaymentType, Status, MemberID) "
                        + "VALUES (?, CURRENT_DATE + INTERVAL '1 month', ?, 'Paid', ?)";
                try (PreparedStatement pstmtBill = conn.prepareStatement(billsSQL)) {
                    pstmtBill.setBigDecimal(1, BigDecimal.valueOf(membershipPrice));
                    pstmtBill.setString(2, paymentType);
                    pstmtBill.setInt(3, newMemberId);  // Assuming newMemberId was retrieved from the Member insert

                    int affectedRows = pstmtBill.executeUpdate();
                    if (affectedRows == 0) {
                        throw new SQLException("Failed to create a bill for the new member.");
                    }


                    System.out.println("Payment received via " + paymentType + ". Registration completed successfully. Your member ID is: " + newMemberId);

                    conn.commit();
                }
                    System.out.println("Registration completed successfully. Your member ID is: " + newMemberId);
                } catch (SQLException e) {
                    conn.rollback();
                    throw e;
            }

        } catch (Exception e) {
            System.err.println("An error occurred.");
            e.printStackTrace();
        }
    }

    private static void updateProfile(Scanner scanner, Connection conn) {
        try {
            // Begin transaction
            conn.setAutoCommit(false);

            System.out.println("Enter your Member ID:");
            int memberId = Integer.parseInt(scanner.nextLine());

            System.out.println("What would you like to update?");
            System.out.println("1. Personal Information");
            System.out.println("2. Fitness Goals");
            System.out.println("3. Health Metrics");
            System.out.println("4. Update Progress on Goals");
            String choice = scanner.nextLine();

            switch (choice) {
                case "1": // Update Personal Information
                    System.out.println("Enter new email:");
                    String email = scanner.nextLine();

                    System.out.println("Enter new address:");
                    String address = scanner.nextLine();

                    System.out.println("Enter new phone number:");
                    String phone = scanner.nextLine();

                    String updatePersonalInfoSQL = "UPDATE Member SET Email = ?, Address = ?, Phone = ? WHERE MemberID = ?";
                    try (PreparedStatement pstmt = conn.prepareStatement(updatePersonalInfoSQL)) {
                        pstmt.setString(1, email);
                        pstmt.setString(2, address);
                        pstmt.setString(3, phone);
                        pstmt.setInt(4, memberId);
                        pstmt.executeUpdate();
                    }
                    break;


                case "2": // Update Fitness Goals
                    System.out.println("Enter new weight goal (kg):");
                    double weightGoal = Double.parseDouble(scanner.nextLine());

                    System.out.println("Enter new body fat goal (%):");
                    double bodyFatGoal = Double.parseDouble(scanner.nextLine());

                    String updateFitnessGoalsSQL = "UPDATE Member SET WeightGoal = ?, BodyFatGoal = ? WHERE MemberID = ?";
                    try (PreparedStatement pstmt = conn.prepareStatement(updateFitnessGoalsSQL)) {
                        pstmt.setDouble(1, weightGoal);
                        pstmt.setDouble(2, bodyFatGoal);
                        pstmt.setInt(3, memberId);
                        pstmt.executeUpdate();
                    }
                    break;

                case "3": // Update Health Metrics
                    System.out.println("Enter new current weight (kg):");
                    double weight = Double.parseDouble(scanner.nextLine());

                    System.out.println("Enter new current body fat (%):");
                    double bodyFat = Double.parseDouble(scanner.nextLine());

                    String updateHealthMetricsSQL = "UPDATE Member SET Weight = ?, BodyFat = ? WHERE MemberID = ?";
                    try (PreparedStatement pstmt = conn.prepareStatement(updateHealthMetricsSQL)) {
                        pstmt.setDouble(1, weight);
                        pstmt.setDouble(2, bodyFat);
                        pstmt.setInt(3, memberId);
                        pstmt.executeUpdate();
                    }
                    break;


                case "4": // Update Progress on Goals
                    System.out.println("Enter new weight goal status (e.g., Achieved, In Progress):");
                    String weightGoalStatus = scanner.nextLine();

                    System.out.println("Enter new body fat goal status (e.g., Achieved, In Progress):");
                    String bodyFatGoalStatus = scanner.nextLine();

                    String updateGoalSQL = "UPDATE Member SET WeightGoalStatus = ?, BodyFatGoalStatus = ? WHERE MemberID = ?";
                    try (PreparedStatement pstmt = conn.prepareStatement(updateGoalSQL)) {
                        pstmt.setString(1, weightGoalStatus);
                        pstmt.setString(2, bodyFatGoalStatus);
                        pstmt.setInt(3, memberId);
                        pstmt.executeUpdate();
                    }
                    break;

                default:
                    System.out.println("Invalid choice. No updates made.");
                    return;
            }

            conn.commit();

            String selectSQL = "SELECT * FROM Member WHERE MemberID = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(selectSQL)) {
                pstmt.setInt(1, memberId);
                ResultSet rs = pstmt.executeQuery();
                if (rs.next()) {
                    System.out.println("Updated Profile Information:");
                    System.out.println("Name: " + rs.getString("Name"));
                    System.out.println("Email: " + rs.getString("Email"));
                    System.out.println("Address: " + rs.getString("Address"));
                    System.out.println("Phone: " + rs.getString("Phone"));
                    System.out.println("Weight: " + rs.getDouble("Weight"));
                    System.out.println("Body Fat: " + rs.getDouble("BodyFat"));
                    System.out.println("Weight Goal: " + rs.getDouble("WeightGoal"));
                    System.out.println("Weight Goal Status: " + rs.getString("WeightGoalStatus"));
                    System.out.println("Body Fat Goal: " + rs.getDouble("BodyFatGoal"));
                    System.out.println("Body Fat Goal Status: " + rs.getString("BodyFatGoalStatus"));
                } else {
                    System.out.println("No member found with ID: " + memberId);
                }
            }

            System.out.println("Profile updated successfully!");

        } catch (Exception e) {
            System.err.println("An error occurred.");
            e.printStackTrace();
        }
    }
    public static void trainerManageSchedule(Scanner scanner, Connection conn){
        try {
            conn.setAutoCommit(false);

            System.out.println("Enter the Trainer ID for which you want to add a time slot:");
            int trainerId = Integer.parseInt(scanner.nextLine());

            System.out.println("Enter the date for the time slot (YYYY-MM-DD):");
            String dateInput = scanner.nextLine();
            java.sql.Date date = java.sql.Date.valueOf(dateInput); // Converting string input to sql.Date

            System.out.println("Enter the time for the time slot (HH:MM):");
            String timeInput = scanner.nextLine();
            java.sql.Time time = java.sql.Time.valueOf(timeInput + ":00"); // Adding seconds for Time value

            // Insert the new time slot into the database
            String insertSQL = "INSERT INTO Time_Slots (TrainerID, Time, Date) VALUES (?, ?, ?)";
            try (PreparedStatement pstmt = conn.prepareStatement(insertSQL)) {
                pstmt.setInt(1, trainerId);
                pstmt.setTime(2, time);
                pstmt.setDate(3, date);

                int affectedRows = pstmt.executeUpdate();
                if (affectedRows == 0) {
                    throw new SQLException("Inserting time slot failed, no rows affected.");
                }

                conn.commit();
                System.out.println("Time slot added successfully for Trainer ID " + trainerId + " on " + date + " at " + time);
            }
        }catch (Exception e) {
            System.err.println("An error occurred.");
            e.printStackTrace();
        }
    }
    public static void memberScheduling(Scanner scanner, Connection conn){

        try {
            // Begin transaction
            conn.setAutoCommit(false);

            System.out.println("Enter your Member ID:");
            int memberId = Integer.parseInt(scanner.nextLine());

            // List available trainers
            System.out.println("Available Trainers:");
            String trainerSQL = "SELECT TrainerID, Name, Specialization FROM Trainer";
            try (PreparedStatement pstmtTrainer = conn.prepareStatement(trainerSQL)) {
                ResultSet rsTrainers = pstmtTrainer.executeQuery();
                while (rsTrainers.next()) {
                    System.out.println("Trainer ID: " + rsTrainers.getInt("TrainerID") + ", Name: " + rsTrainers.getString("Name") + ", Specialization: " + rsTrainers.getString("Specialization"));
                }
            }

            System.out.println("Select a Trainer ID:");
            int trainerId = Integer.parseInt(scanner.nextLine());

            // List available time slots for the selected trainer
            String timeSlotSQL = "SELECT Time, Date FROM Time_Slots WHERE TrainerID = ? AND Date >= CURRENT_DATE ORDER BY Date, Time";
            try (PreparedStatement pstmtTimeSlot = conn.prepareStatement(timeSlotSQL)) {
                pstmtTimeSlot.setInt(1, trainerId);
                ResultSet rsTimeSlots = pstmtTimeSlot.executeQuery();

                List<java.sql.Timestamp> times = new ArrayList<>();
                int index = 1;
                while (rsTimeSlots.next()) {
                    java.sql.Time time = rsTimeSlots.getTime("Time") ;
                    java.sql.Date date = rsTimeSlots.getDate("Date");
                    times.add(new java.sql.Timestamp((time.getTime() - (1000 * 60 * 60 * 5)) + date.getTime()));
                    System.out.println(index + ". " + time + " on " + date);
                    index++;
                }

                if (times.isEmpty()) {
                    System.out.println("No available times for the selected trainer. Please try another trainer or check back later.");
                    return;
                }

                System.out.println("Select a time by index:");
                int timeChoice = Integer.parseInt(scanner.nextLine());
                if (timeChoice < 1 || timeChoice > times.size()) {
                    System.out.println("Invalid choice. Please select a valid number.");
                    return;
                }

                java.sql.Timestamp selectedTime = times.get(timeChoice - 1);

                // Check and/or Create the session if it doesn't exist
                String checkOrCreateSessionSQL = "SELECT SessionID FROM Sessions WHERE TrainerID = ? AND Time = ? AND Date = ?";
                int sessionId;
                try (PreparedStatement pstmtCheckSession = conn.prepareStatement(checkOrCreateSessionSQL, Statement.RETURN_GENERATED_KEYS)) {
                    pstmtCheckSession.setInt(1, trainerId);
                    pstmtCheckSession.setTime(2, new java.sql.Time(selectedTime.getTime()));
                    pstmtCheckSession.setDate(3, new java.sql.Date(selectedTime.getTime()));
                    ResultSet rsSession = pstmtCheckSession.executeQuery();
                    if (rsSession.next()) {
                        sessionId = rsSession.getInt("SessionID");
                    } else {
                        // If session does not exist, create one
                        String createSessionSQL = "INSERT INTO Sessions (TrainerID, SessionType, Time, Date) VALUES (?, 'Standard', ?, ?) RETURNING SessionID";
                        try (PreparedStatement pstmtCreateSession = conn.prepareStatement(createSessionSQL)) {
                            pstmtCreateSession.setInt(1, trainerId);
                            pstmtCreateSession.setTime(2, new java.sql.Time(selectedTime.getTime()));
                            pstmtCreateSession.setDate(3, new java.sql.Date(selectedTime.getTime()));
                            ResultSet rsCreateSession = pstmtCreateSession.executeQuery();
                            if (rsCreateSession.next()) {
                                sessionId = rsCreateSession.getInt("SessionID");
                            } else {
                                throw new SQLException("Failed to create a new session.");
                            }
                        }
                    }
                }

                // Schedule the member for the session
                String scheduleSQL = "INSERT INTO Member_Sessions (MemberID, SessionID, Date, AttendanceStatus) VALUES (?, ?, ?, 'Scheduled')";
                try (PreparedStatement pstmtSchedule = conn.prepareStatement(scheduleSQL)) {
                    pstmtSchedule.setInt(1, memberId);
                    pstmtSchedule.setInt(2, sessionId);
                    pstmtSchedule.setDate(3, new java.sql.Date(selectedTime.getTime()));
                    int affectedRows = pstmtSchedule.executeUpdate();
                    if (affectedRows == 0) {
                        throw new SQLException("Failed to schedule the session. Please ensure the selected time is available.");
                    }
                    conn.commit();
                    System.out.println("Session scheduled successfully for " + new java.sql.Time(selectedTime.getTime()) + " on " + new java.sql.Date(selectedTime.getTime()));
                    String deleteTimeSlotSQL = "DELETE FROM Time_Slots WHERE TrainerID = ? AND Time = ? AND Date = ?";
                    try (PreparedStatement pstmtDeleteTimeSlot = conn.prepareStatement(deleteTimeSlotSQL)) {
                        pstmtDeleteTimeSlot.setInt(1, trainerId);
                        pstmtDeleteTimeSlot.setTime(2, new java.sql.Time(selectedTime.getTime()));
                        pstmtDeleteTimeSlot.setDate(3, new java.sql.Date(selectedTime.getTime()));
                        pstmtDeleteTimeSlot.executeUpdate();
                    }
                }
            }

            // Reset auto-commit to default
            conn.setAutoCommit(true);
        } catch (Exception e) {
            System.err.println("An error occurred.");
            e.printStackTrace();
        }
    }

}
